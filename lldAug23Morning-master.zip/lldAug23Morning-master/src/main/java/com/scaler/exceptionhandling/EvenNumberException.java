package com.scaler.exceptionhandling;

public class EvenNumberException extends Exception {
}
