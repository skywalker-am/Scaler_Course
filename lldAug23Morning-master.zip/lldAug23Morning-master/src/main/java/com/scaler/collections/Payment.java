package com.scaler.collections;

public class Payment {

//    String status; // "pending" / "failed" / "success" / "pata nahi"/ "mujhe kya pata"
    // human readable value
    // from a fixed set of values

    PaymentStatus status;
}
