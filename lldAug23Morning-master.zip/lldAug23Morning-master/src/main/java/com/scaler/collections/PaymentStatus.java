package com.scaler.collections;

public enum PaymentStatus {
    SUCCESS,
    FAILURE,
    PENDING,
    AWAITING_BANK_APPROVAL,

//    String doSomethingFun() {
//        System.out.println("Hi");
//    }
}
