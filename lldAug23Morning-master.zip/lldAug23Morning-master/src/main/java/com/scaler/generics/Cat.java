package com.scaler.generics;

public class Cat extends Animal {
    String sound = "Meow";

    @Override
    public void hey() {
        System.out.println("Hey Cat");
    }
}
