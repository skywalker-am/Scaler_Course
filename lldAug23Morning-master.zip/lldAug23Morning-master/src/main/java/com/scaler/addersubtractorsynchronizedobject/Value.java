package com.scaler.addersubtractorsynchronizedobject;

public class Value {
    public int value = 0;
}
