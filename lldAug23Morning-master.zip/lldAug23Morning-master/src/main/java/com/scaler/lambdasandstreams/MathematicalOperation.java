package com.scaler.lambdasandstreams;

public interface MathematicalOperation {

    Integer operate(Integer a, Integer b);
}
