package com.scaler.addersubtractormutex;

public class Value {
    public int value = 0;
}
