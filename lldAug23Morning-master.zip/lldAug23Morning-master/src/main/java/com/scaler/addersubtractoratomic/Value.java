package com.scaler.addersubtractoratomic;

import java.util.concurrent.atomic.AtomicInteger;

public class Value {
    public AtomicInteger atomicInteger = new AtomicInteger(0);
}
