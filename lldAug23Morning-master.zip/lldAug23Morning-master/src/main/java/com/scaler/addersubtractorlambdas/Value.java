package com.scaler.addersubtractorlambdas;

public class Value {
    public int value = 0;
}
