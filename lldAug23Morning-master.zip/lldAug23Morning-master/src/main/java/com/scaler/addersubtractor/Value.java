package com.scaler.addersubtractor;

public class Value {
    public int value = 0;
}
